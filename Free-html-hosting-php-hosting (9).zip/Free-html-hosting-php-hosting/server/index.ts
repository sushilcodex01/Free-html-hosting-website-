import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';
import fs from 'fs';
import archiver from 'archiver';
import unzipper from 'unzipper';

// Get the directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Use port 5000 as default for Replit workflows, or use the provided PORT from env
const port = process.env.PORT ? parseInt(process.env.PORT) : 5000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${path.parse(file.originalname).name}_${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({ 
  storage,
  limits: { 
    fileSize: 20 * 1024 * 1024 // 20MB for ZIP files
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.html', '.css', '.js', '.txt', '.zip'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('File type not allowed'));
    }
  }
});

// In-memory file storage (for this demo)
let uploadedFiles: any[] = [];

// Serve static files from the root directory
app.use(express.static(path.join(__dirname, '..')));
app.use('/uploads', express.static(uploadsDir));

// Serve libraries from CDN fallback if needed
app.use('/vendor', express.static(path.join(__dirname, '../node_modules')));

// API Routes
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    const file = req.file;
    const fileInfo: any = {
      name: file.originalname,
      unique_name: file.filename,
      size: file.size,
      extension: path.extname(file.originalname).toLowerCase().slice(1),
      upload_time: Date.now(),
      path: file.path,
      public_url: `${req.protocol}://${req.get('host')}/uploads/${file.filename}`,
      is_folder: false
    };

    // Handle ZIP files (HTML folder uploads)
    if (fileInfo.extension === 'zip') {
      try {
        const extractPath = path.join(uploadsDir, `folder_${Date.now()}`);
        fs.mkdirSync(extractPath, { recursive: true });

        // Extract ZIP file
        await fs.createReadStream(file.path)
          .pipe(unzipper.Extract({ path: extractPath }))
          .promise();

        // Delete the ZIP file after extraction
        fs.unlinkSync(file.path);

        // Look for index.html
        const indexFile = findIndexHtml(extractPath);
        const folderName = path.basename(extractPath);
        const folderUrl = `${req.protocol}://${req.get('host')}/uploads/${folderName}`;
        const indexUrl = indexFile ? `${folderUrl}/${indexFile}` : null;

        fileInfo.unique_name = folderName;
        fileInfo.extension = 'folder';
        fileInfo.path = extractPath;
        fileInfo.public_url = folderUrl;
        fileInfo.index_url = indexUrl;
        fileInfo.is_folder = true;

        uploadedFiles.push(fileInfo);

        res.json({
          success: true,
          message: 'HTML folder uploaded successfully!',
          file_url: indexUrl || folderUrl,
          folder_url: folderUrl,
          index_url: indexUrl
        });
      } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to extract ZIP file' });
      }
    } else {
      // Regular file upload
      uploadedFiles.push(fileInfo);
      res.json({
        success: true,
        message: 'File uploaded successfully!',
        file_url: fileInfo.public_url
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Upload failed' });
  }
});

// Get uploaded files
app.get('/api/files', (req, res) => {
  res.json(uploadedFiles);
});

// Delete file
app.delete('/api/files/:filename', (req, res) => {
  const filename = req.params.filename;
  const fileIndex = uploadedFiles.findIndex(f => f.unique_name === filename);
  
  if (fileIndex !== -1) {
    const file = uploadedFiles[fileIndex];
    
    // Delete physical file or folder
    if (file.is_folder) {
      fs.rmSync(file.path, { recursive: true, force: true });
    } else {
      if (fs.existsSync(file.path)) {
        fs.unlinkSync(file.path);
      }
    }
    
    uploadedFiles.splice(fileIndex, 1);
    res.json({ success: true });
  } else {
    res.status(404).json({ success: false, message: 'File not found' });
  }
});

// Utility function to find index.html
function findIndexHtml(dirPath: string): string | null {
  const files = fs.readdirSync(dirPath, { withFileTypes: true });
  
  for (const file of files) {
    if (file.isFile() && file.name.toLowerCase() === 'index.html') {
      return file.name;
    } else if (file.isDirectory()) {
      const subResult = findIndexHtml(path.join(dirPath, file.name));
      if (subResult) {
        return `${file.name}/${subResult}`;
      }
    }
  }
  
  return null;
}

// Define specific routes first
app.get('/studyfocus.html', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'studyfocus.html'));
});

// Route for main application
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'src', 'index.html'));
});

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`Free HTML Hosting Platform listening at http://localhost:${port}`);
});