<?php
// Redirect to main page if someone tries to access uploads directly
header('Location: ../index.php');
exit;
?>